// MODERATE-1

package com.ampos.moderate1;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class QuizModerate1 {
    public int run(List<TableReservation> customerList) {
        return -1;
    }
}
