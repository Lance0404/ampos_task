package com.ampos.moderate1;

public class TableReservation {
    public String startTime;
    public String endTime;
    
    public TableReservation(String startTime, String endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
    }
}