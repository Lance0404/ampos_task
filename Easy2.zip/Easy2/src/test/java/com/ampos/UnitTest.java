package com.ampos;

import org.junit.Test;
import com.ampos.easy2.*;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class UnitTest {
    @Test
    public void testCase1() {
        QuizEasy2 answerClass = new QuizEasy2();
        
        int[][] input = new int[3][3];
        
        int count = 1;
        
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                input[i][j] = count;
                count += 1;
            }
        }
        
        int[][] result = answerClass.run(input);
        assertThat(result[0][0], is(3));
        assertThat(result[0][1], is(6));
        assertThat(result[0][2], is(9));

        assertThat(result[1][0], is(2));
        assertThat(result[1][1], is(5));
        assertThat(result[1][2], is(8));
        
        assertThat(result[2][0], is(1));
        assertThat(result[2][1], is(4));
        assertThat(result[2][2], is(7));
    }
    
    @Test
    public void testCase2() {
        QuizEasy2 answerClass = new QuizEasy2();
        
        int[][] input = new int[4][4];
        
        int count = 1;
        
        for(int i = 0; i < 4; i++) {
            for(int j = 0; j < 4; j++) {
                input[i][j] = count;
                count += 1;
            }
        }
        
        int[][] result = answerClass.run(input);
        assertThat(result[0][0], is(4));
        assertThat(result[0][1], is(8));
        assertThat(result[0][2], is(12));
        assertThat(result[0][3], is(16));
        
        assertThat(result[1][0], is(3));
        assertThat(result[1][1], is(7));
        assertThat(result[1][2], is(11));
        assertThat(result[1][3], is(15));
        
        assertThat(result[2][0], is(2));
        assertThat(result[2][1], is(6));
        assertThat(result[2][2], is(10));
        assertThat(result[2][3], is(14));
        
        assertThat(result[3][0], is(1));
        assertThat(result[3][1], is(5));
        assertThat(result[3][2], is(9));
        assertThat(result[3][3], is(13));
    }
}