// Easy-2

package com.ampos.easy2;

public class QuizEasy2 {
    public int[][] run(int[][] input) {
        return new int[1][1];
    }
}