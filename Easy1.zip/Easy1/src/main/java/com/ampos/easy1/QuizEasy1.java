// Easy-1

package com.ampos.easy1;

public class QuizEasy1 {
    public int run(String inputChar) {
        return result;
    }
}