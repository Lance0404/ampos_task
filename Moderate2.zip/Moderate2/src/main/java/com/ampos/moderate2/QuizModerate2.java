// MODERATE-2

package com.ampos.moderate2;

public class QuizModerate2 {
    public int[][] run(int input) {
        return new int[][];
    }
}