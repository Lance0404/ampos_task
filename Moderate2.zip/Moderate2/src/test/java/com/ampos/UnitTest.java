package com.ampos;

import org.junit.Test;
import com.ampos.moderate2.*;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertNull;

public class UnitTest {
    @Test
    public void testCase1() {
        QuizModerate2 answerClass = new QuizModerate2();
        
        int[][] result = answerClass.run(3);
        
        assertThat(result[0][0], is(4));
        assertThat(result[0][1], is(2));
        assertThat(result[0][2], is(1));

        assertThat(result[1][0], is(7));
        assertThat(result[1][1], is(5));
        assertThat(result[1][2], is(3));
        
        assertThat(result[2][0], is(9));
        assertThat(result[2][1], is(8));
        assertThat(result[2][2], is(6));
    }
    
    @Test
    public void testCase2() {
        QuizModerate2 answerClass = new QuizModerate2();
        
        int[][] result = answerClass.run(4);
        
        assertThat(result[0][0], is(7));
        assertThat(result[0][1], is(4));
        assertThat(result[0][2], is(2));
        assertThat(result[0][3], is(1));

        assertThat(result[1][0], is(11));
        assertThat(result[1][1], is(8));
        assertThat(result[1][2], is(5));
        assertThat(result[1][3], is(3));
        
        assertThat(result[2][0], is(14));
        assertThat(result[2][1], is(12));
        assertThat(result[2][2], is(9));
        assertThat(result[2][3], is(6));
        
        assertThat(result[3][0], is(16));
        assertThat(result[3][1], is(15));
        assertThat(result[3][2], is(13));
        assertThat(result[3][3], is(10));
    }
}