package com.ampos;

import org.junit.Test;
import com.ampos.easy3.*;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertNull;

public class UnitTest {
    @Test
    public void testCase1() {
        QuizEasy3 answerClass = new QuizEasy3();
        
        Node nodeD = new Node("D", null);
        Node nodeC = new Node("C", nodeD);
        Node nodeB = new Node("B", nodeC);
        Node input = new Node("A", nodeB);
        
        String result = answerClass.run(input);
        assertNull(result);
    }
    
    @Test
    public void testCase2() {
        QuizEasy3 answerClass = new QuizEasy3();
        
        Node nodeD = new Node("D", null);
        Node nodeC = new Node("C", nodeD);
        Node nodeB = new Node("B", nodeC);
        nodeD.setNextNode(nodeB);
        Node input = new Node("A", nodeB);
        
        String result = answerClass.run(input);
        assertThat(result, is("B"));
    }
}