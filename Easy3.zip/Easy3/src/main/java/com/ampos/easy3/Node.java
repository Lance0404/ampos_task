package com.ampos.easy3;

public class Node {
    String name;
    Node nextNode;
    
    public Node(String name, Node nextNode) {
        this.name = name;
        this.nextNode = nextNode;
    }
    
    public void setNextNode(Node nextNode) {
        this.nextNode = nextNode;
    }
}
