// Easy-3

package com.ampos.easy3;

public class QuizEasy3 {
    public String run(Node input) {
        return "AAA";
    }
}