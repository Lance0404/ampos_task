// Easy-4

package com.ampos.easy4;

public class QuizEasy4 {
    public int run(String input) {
        return -1;
    }
}