package com.ampos;

import org.junit.Test;
import com.ampos.easy4.*;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertNull;

public class UnitTest {
    @Test
    public void testCase1() {
        QuizEasy4 answerClass = new QuizEasy4();
        
        int result = answerClass.run("abcabcabc");
        assertThat(result, is(3));
    }
    
    @Test
    public void testCase2() {
        QuizEasy4 answerClass = new QuizEasy4();
        
        int result = answerClass.run("aaaaa");
        assertThat(result, is(1));
    }
    
    @Test
    public void testCase3() {
        QuizEasy4 answerClass = new QuizEasy4();
        
        int result = answerClass.run("arrghare");
        assertThat(result, is(5));
    }
}